// Morse code converter interface
interface MorseCodeConverter {
    /**
     * Converts input to Morse code or plain text, depending on the implementation.
     *
     * @param input The input to be converted.
     * @return The converted Morse code or plain text.
     * @throws ConversionException If an error occurs during the conversion.
     */
    String convert(String input) throws ConversionException;
}
