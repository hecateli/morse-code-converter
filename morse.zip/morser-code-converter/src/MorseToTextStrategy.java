import java.util.Map;

// Concrete strategy for Morse code to text conversion
class MorseToTextStrategy implements MorseCodeConversionStrategy {
    private final Map<String, Character> morseToTextMapping;

    public MorseToTextStrategy(Map<String, Character> morseToTextMapping) {
        this.morseToTextMapping = morseToTextMapping;
    }

    @Override
    public String convert(String morseCode) throws ConversionException {
        StringBuilder result = new StringBuilder();
        String[] words = morseCode.trim().split("\\s{3,}"); // Split into words

        for (String word : words) {
            String[] letters = word.split("\\s+"); // Split into letters
            for (String letter : letters) {
                if (morseToTextMapping.containsKey(letter.toUpperCase())) {
                    result.append(morseToTextMapping.get(letter));
                } else {
                    throw new ConversionException("Invalid Morse code character found: " + letter);
                }
            }
            result.append(' '); // Add space between words
        }

        return result.toString().trim();
    }
}