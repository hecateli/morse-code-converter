import java.util.Map;

// Concrete strategy for text to Morse code conversion
class TextToMorseStrategy implements MorseCodeConversionStrategy {
    private final Map<Character, String> textToMorseMapping;

    public TextToMorseStrategy(Map<Character, String> mapping) {
        this.textToMorseMapping = mapping;
    }

    @Override
    public String convert(String text) throws ConversionException {
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isWhitespace(c)) {
                result.append("   "); // Add three spaces for word separation
            } else if (textToMorseMapping.containsKey(Character.toUpperCase(c))) {
                result.append(textToMorseMapping.get(Character.toUpperCase(c))).append(" ");
            } else {
                throw new ConversionException("Invalid character found: " + c);
            }
        }

        return result.toString().trim();
    }
}
