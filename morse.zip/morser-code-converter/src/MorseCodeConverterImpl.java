import java.io.*;

// Morse code converter implementation
class MorseCodeConverterImpl implements MorseCodeConverter {
    private final MorseCodeConversionStrategy strategy;

    public MorseCodeConverterImpl(MorseCodeConversionStrategy strategy) {
        this.strategy = strategy;
    }
    @Override
    public String convert(String input) throws ConversionException {
        try {
            return strategy.convert(input);
        } catch (ConversionException e) {
            throw e;
        } catch (Exception e) {
            throw new ConversionException("Error converting input: " + e.getMessage());
        }
    }

    // Save previous conversions to a file
    public static void saveConversionsToFile(String fileName, String content) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
            writer.print(content);
        } catch (IOException e) {
            System.err.println("Error saving conversions to file: " + e.getMessage());
        }
    }

    // Load previous conversions from a file
    public static String loadConversionsFromFile(String fileName) {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append(System.lineSeparator());
            }
        } catch (IOException e) {
            System.err.println("Error loading conversions from file: " + e.getMessage());
        }
        return content.toString();
    }
}
