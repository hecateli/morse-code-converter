import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

// Helper method to allow user input for custom mapping
class CustomMappingUtil {
    /**
     * Allows the user to input custom Morse code to text mapping.
     *
     * @return The custom Morse code to text mapping.
     */
    public static Map<String, Character> createMorseToTextMapping() {
        Map<String, Character> mapping = new HashMap<>();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter Morse code to Character mappings (or type 'done' to finish):");
        System.out.println("The standard mapping: .- A -... B -.-. C -.. D . E ..-. F --. G .... H .. I .--- J -.- K .-.. L -- M -. N --- O .--. P --.- Q .-. R ... S - T ..- U ...- V .-- W -..- X -.-- Y --.. Z");
        while (true) {
            System.out.print("Morse code and Character pairs (e.g., .- A -... B): ");
            String inputLine = scanner.nextLine();

            if (inputLine.equalsIgnoreCase("done")) {
                break; // Exit the loop if the user types 'done'
            }

            String[] pairs = inputLine.split("\\s+");
            if (pairs.length % 2 != 0) {
                System.out.println("Invalid input format. Each pair should consist of a Morse code and a character.");
                continue; // Skip to the next iteration
            }

            for (int i = 0; i < pairs.length; i += 2) {
                String morseCode = pairs[i];
                char character = pairs[i + 1].charAt(0);
                mapping.put(morseCode, character);
            }
        }

        return mapping;
    }

    /**
     * Allows the user to input custom text to Morse code mapping.
     *
     * @return The custom text to Morse code mapping.
     */
    public static Map<Character, String> createTextToMorseMapping() {
        Map<Character, String> mapping = new HashMap<>();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter Character to Morse Code mapping (or type 'done' to finish):");
        System.out.println("The standard mapping: A .- B -... C -.-. D -.. E . F ..-. G --. H .... I .. J .--- K -.- L .-.. M -- N -. O --- P .--. Q --.- R .-. S ... T - U ..- V ...- W .-- X -..- Y -.-- Z --..");
        while (true) {
            System.out.print("Character and Morse code pairs (e.g., A .- B -...): ");
            String inputLine = scanner.nextLine();

            if (inputLine.equalsIgnoreCase("done")) {
                break; // Exit the loop if the user types 'done'
            }

            String[] pairs = inputLine.split("\\s+");
            if (pairs.length % 2 != 0) {
                System.out.println("Invalid input format. Each pair should consist of a character and Morse code.");
                continue; // Skip to the next iteration
            }

            for (int i = 0; i < pairs.length; i += 2) {
                char character = pairs[i].charAt(0);
                String morseCode = pairs[i + 1];
                mapping.put(character, morseCode);
            }
        }
        return mapping;
    }
}
