import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Display menu and get user choice
        System.out.println("Choose an option:");
        System.out.println("1. Morse to Text Conversion");
        System.out.println("2. Text to Morse Conversion");
        int choice = scanner.nextInt();

        // Create appropriate converter based on user choice
        MorseCodeConverter converter;
        if (choice == 1) {
            Map<String, Character> morseToTextMapping = CustomMappingUtil.createMorseToTextMapping();
            converter = MorseCodeConverterFactory.createMorseToTextConverter(morseToTextMapping);
        } else if (choice == 2) {
            Map<Character, String> textToMorseMapping = CustomMappingUtil.createTextToMorseMapping();
            converter = MorseCodeConverterFactory.createTextToMorseConverter(textToMorseMapping);
        } else {
            System.out.println("Invalid choice. Exiting.");
            return;
        }

        // Perform conversion
        System.out.println("Enter the input:");
        scanner.nextLine(); // Consume newline
        String input = scanner.nextLine();
        try {
            String result = converter.convert(input);
            System.out.println("Conversion Result:");
            System.out.println(result);

            // Save and load previous conversions
            MorseCodeConverterImpl.saveConversionsToFile("previous_conversions.txt", result);
            String loadedResult = MorseCodeConverterImpl.loadConversionsFromFile("previous_conversions.txt");
            System.out.println("Loaded Result from File:");
            System.out.println(loadedResult);

        } catch (ConversionException e) {
            System.out.println("Error during conversion: " + e.getMessage());
        }
    }
}