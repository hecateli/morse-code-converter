import java.util.Map;

// Morse code converter factory
class MorseCodeConverterFactory {
    /**
     * Creates a Morse code to text converter with custom mapping.
     *
     * @param customMapping The custom Morse code to text mapping.
     * @return The Morse code converter instance.
     */
    public static MorseCodeConverter createMorseToTextConverter(Map<String, Character> customMapping) {
        MorseCodeConversionStrategy strategy = new MorseToTextStrategy(customMapping);
        return new MorseCodeConverterImpl(strategy);
    }

    /**
     * Creates a text to Morse code converter with custom mapping.
     *
     * @param customMapping The custom text to Morse code mapping.
     * @return The Morse code converter instance.
     */
    public static MorseCodeConverter createTextToMorseConverter(Map<Character, String> customMapping) {
        MorseCodeConversionStrategy strategy = new TextToMorseStrategy(customMapping);
        return new MorseCodeConverterImpl(strategy);
    }
}
