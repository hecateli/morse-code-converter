// JUnit test class for MorseToTextStrategy
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

class MorseToTextStrategyTest {
    private final Map<String, Character> testMapping = new HashMap<>();

    private final MorseToTextStrategy morseToTextConverter = new MorseToTextStrategy(testMapping);

    @Test
    void testInvalidMorseCode() {
        // Test invalid Morse code with unknown characters
        String invalidMorseCode = "--.-..--.";

        try {
            morseToTextConverter.convert(invalidMorseCode);
            Assertions.fail("Expected ConversionException, but no exception was thrown.");
        } catch (ConversionException e) {
            Assertions.assertEquals("Invalid Morse code character found: --.-..--.", e.getMessage());
        }
    }
}