import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;


class TextToMorseStrategyTest {
    private final Map<Character, String> testMapping = new HashMap<>();

    private final TextToMorseStrategy converter = new TextToMorseStrategy(testMapping);

    @Test
    void testInvalidMorseCode() {
        // Test invalid Morse code with unknown characters
        String invalidText = ".#$23";

        try {
            converter.convert(invalidText);
            Assertions.fail("Expected ConversionException, but no exception was thrown.");
        } catch (ConversionException e) {
            Assertions.assertEquals("Invalid character found: .", e.getMessage());
        }
    }
}